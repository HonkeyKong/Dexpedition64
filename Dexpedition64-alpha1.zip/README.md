# Dexpedition64

This is a save manager for the Nintendo 64, meant to be used with the DexDrive. Right now it only supports formatting N64 memory cards, as well as reading and writing MPK files. Hardware serial ports as well as USB to Serial converters have been tested and confirmed to work.

Licensed under GPLv3, as per the terms of [MemCardRex](https://github.com/ShendoXT/memcardrex), from which some of the DexDrive communication code was borrowed.